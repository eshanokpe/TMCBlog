<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
          Posts Edit (<b>Author: </b> <?php echo e($post->author->name); ?>)
        </h2>
     <?php $__env->endSlot(); ?>
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">
                   
                    <form method="POST" action="<?php echo e(route('admin.posts.update',$post->id)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="flex-col flex py-3">
                            <label class="pb-2 text-gray-700 font-semibold">Title</label>
                            <input type="text" class="p-2 shadow rounded-lg bg-gray-100 outline-none focus:bg-gray-200" placeholder="title" name="title" value="<?php echo e($post->title); ?>">
                        </div>
                        <div class="flex-col flex py-3">
                            <label class="pb-2 text-gray-700 font-semibold">Description</label>
                            <textarea type="text" class="p-2 shadow rounded-lg bg-gray-100 outline-none focus:bg-gray-200" rows="9" placeholder="content" name="content"><?php echo e($post->content); ?></textarea>
                        </div>

                        <div class="flex-col flex py-3">
                            <label class="pb-2 text-gray-700 font-semibold">Image</label>
                            <div class="inner">
                                <img src="<?php echo e(asset('images/'.$post->image)); ?>" width="90" height="90" alt="post-title" />
                            </div>
                        </div>
                        <div class="flex-col flex py-3">
                            <input type="file" class="p-2 shadow rounded-lg bg-gray-100 outline-none focus:bg-gray-200" placeholder="title" name="image" value="<?php echo e($post->image); ?>">
                        </div>

                        <button class="px-4 py-2 rounded text-white inline-block shadow-lg bg-blue-500 hover:bg-blue-600 focus:bg-blue-700" type="submit">Update</button>
                        
                    </form>


                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\laravel\auth_breeze\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>