
<div class="scrollbar-sidebar">
    <div class="app-sidebar__inner">
    <ul class="vertical-nav-menu">
    <li class="app-sidebar__heading">Dashboards</li>
    <li>
    <a href="index-2.html" class="mm-active">
    Dashboard 
    </a>
    </li>
    <li class="app-sidebar__heading"> Components</li>
    
    </li>

    <li>
        <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
            <?php echo csrf_field(); ?>
            <a href="route('admin.logout')" onclick="event.preventDefault();
            this.closest('form').submit();">
            Logout
            </a>
        </form> 
    </li>
   
    
    
    </ul>
    </div>
    </div>
</div>    <?php /**PATH C:\xampp\htdocs\laravel\auth_breeze\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>