<?php

use Illuminate\Support\Facades\Route;
use App\Models\Post;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
 
Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware(['auth'])->name('dashboard');
Route::get('/viewposts', [App\Http\Controllers\PostController::class, 'index']);
ROute::get('/createpost', [App\Http\Controllers\PostController::class, 'create']);
Route::post('/post/store', [App\Http\Controllers\PostController::class, 'store']);

Route::get('/postshow/{post}', [App\Http\Controllers\PostController::class, 'show']);
Route::put('post/{post}', [App\Http\Controllers\PostController::class, 'update']);
Route::delete('post/{post}', [App\Http\Controllers\PostController::class, 'destroy']);

Route::post('/comments/store', [App\Http\Controllers\CommentController::class, 'store']);

 
       
require __DIR__.'/auth.php';



// Admin 
Route::namespace('Admin')->prefix('admin')->name('admin.')->group(function(){
    Route::namespace('Auth')->middleware('guest:admin')->group(function(){
        // login route
        Route::get('login','AuthenticatedSessionController@create')->name('login');
        Route::post('login','AuthenticatedSessionController@store')->name('adminlogin');
       // Route::get('post/{post}/edit','AuthenticatedSessionController@store')->name('admintest');
    });
    Route::middleware('admin')->group(function(){
        Route::get('dashboard','HomeController@index')->name('dashboard');
       // Route::get('post/{post}/edit', [App\Http\Controllers\HomeController::class, 'edit']);
        Route::delete('post/{post}','HomeController@adminTest');
        Route::get('admin-test','HomeController@adminTest')->name('admintest');
        Route::get('editor-test','HomeController@editorTest')->name('editortest');

        Route::resource('posts','PostController');
        
 
    }); 
    Route::post('logout','Auth\AuthenticatedSessionController@destroy')->name('logout');
});






