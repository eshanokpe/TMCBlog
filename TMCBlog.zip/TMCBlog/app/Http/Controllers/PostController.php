<?php

namespace App\Http\Controllers;
use App\Models\Post;
use App\Models\Comment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $posts = Post::all();
  
        return view('viewposts',['posts'=>$posts]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('createpost');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */ 
    public function store(Request $request)
    {
        $requestData = $request->all();
        $request->validate([
         'title'=> 'required',
         'content' => 'required',
         'image' => 'required|mimes:jpg,png,jpg|max:5045'
        ]);
 
        $newImageName = time(). '-'.$request->image->extension();
        $request->image->extension();
        $request->image->move(public_path('images'), $newImageName);
 
         $post = new Post();
         $post->title = $request->input("title") ;
         $post->content =$request->input("content"); 
         $post->image = $newImageName;
         $post->created_by = Auth::user()->name ;
         $post->admin_id = 1;
                
 
         $post->save();
         return redirect('createpost')->with('status','Post created successfully!');
     }

    
    public function show($id)
    {
        $post = Post::find($id);
       // $comments = Comment::find();
      
  
       // return view('singlepost', compact('post'));
        $comment = Comment::all();
  
        return view('singlepost',['post'=>$post, 'comments'=>$comment]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post)
    {
         if(\Auth::guard('admin')->user()->id == $post->admin_id){
             return view('admin.posts.edit',['post'=>$post]);
        }

         if(\Auth::guard('admin')->user()->can('view',$post)){
         return view('admin.posts.edit',['post'=>$post]);            
         }
        
        $this->authorize('view',$post);
        return view('admin.posts.edit',['post'=>$post]);    
                
    }
 
    

   
    
}
