<?php

namespace App\Http\Controllers;
   
use Illuminate\Http\Request;
use App\Models\Comment;
use Illuminate\Support\Facades\Auth;
   
class CommentController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
          // dd($request->all());
        $input = $request->all();
        $input['user_id'] = Auth::user()->id ;
    
       // Comment::create($input);
        $comment = new comment();
         $comment->email = $request->input("email") ;
         $comment->comment =$request->input("comment"); 
         $comment->name =$request->input("name"); 
         $comment->user_id = Auth::user()->id ;
         $comment->post_id = $request->input('post_id');
         $comment->save();
        
   
        return back()->with('status','Thanks for your comment');
    }
}