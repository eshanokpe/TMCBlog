<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    protected $table = 'posts';
	public $timestamps = true;
    use HasFactory;
    protected $fillable = ['title','content', 'image', 'created_by', 'admin_id'];
 

    public function author(){
        return $this->belongsTo(Admin::class,'admin_id');
    }
}
